import pandas as pd, subprocess, re, sys, unicodedata
all_=pd.read_pickle(sys.argv[1]); pdfdir=sys.argv[2]
fmap={"MasonGrijalva2019":"mason","WangHong2020":"wang_and_hong","HanEtAl2021":"han_etal","YuEtAl2021":"yu_etal","AlAniDas2022":"al_ani","FuEtAl2022":"fu_etal","ShaqourHagishima2022":"shaq","SierlaEtAl2022":"sierla_et","ZhangEtAl2022":"zhang_et_al","ChatterjeeKhovalyg2023":"chatterjae_et","WeinbergEtAl2023":"weinberg-et-al","AlSayedEtAl2024":"al_sayed_et_al","LatonEtAl2024":"laton_et_al","PinthuratEtAl2024":"pinhurat","HuynhEtAl2025":"hynuh_et_al","KannariEtAl2025":"kannari","MichailidisEtAl2025":"michilidas_et","LiEtAl2025":"li_et_al","Togashi2025":"togashi","LeiEtAl2026":"lei_et_al","MazharEtAl2026":"mazhar","MohsenpourXing2026":"mohsenpour"}
def norm(s):
    s=unicodedata.normalize("NFKD",s).encode("ascii","ignore").decode().lower()
    return re.sub(r"[^a-z0-9]","",s)
miss_all=[]
for sid,g in all_.groupby("survey_id"):
    txt=subprocess.run(["pdftotext",f"{pdfdir}/{fmap[sid]}.pdf","-"],capture_output=True,text=True).stdout
    T=norm(txt.replace("-\n",""))
    found=0; miss=[]
    for t in g.title:
        n=norm(t)
        if not n: miss.append("<empty>"); continue
        # check first 40 chars and last 25 chars of the title (robust to line-break hyphenation)
        if n[:40] in T or (len(n)>30 and n[-25:] in T and n[:20] in T): found+=1
        else: miss.append(t[:70])
    print(f"{sid:24s} {found}/{len(g)} titles located in PDF text")
    miss_all+= [(sid,m) for m in miss]
print("\nunlocated examples:")
for sid,m in miss_all[:40]: print(" ",sid,"|",m)
print("total unlocated:",len(miss_all))
