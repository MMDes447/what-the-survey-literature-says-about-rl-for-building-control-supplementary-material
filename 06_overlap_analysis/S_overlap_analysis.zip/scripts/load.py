import pandas as pd, glob, os, sys
D=sys.argv[1]
cols="survey_id,ref_no,first_author_surname,all_authors,year,title,venue,doi,included,included_evidence,study_type,real_building,uncertain,notes".split(",")
frames=[]
for f in sorted(glob.glob(os.path.join(D,"*.csv"))):
    df=pd.read_csv(f,dtype=str,keep_default_na=False)
    sid=os.path.basename(f)[:-4]
    bad = list(df.columns)!=cols
    ids=set(df.survey_id)
    frames.append(df)
    print(f"{sid:24s} rows={len(df):4d} cols_ok={not bad} ids={ids if ids!={sid} else 'ok'} "
          f"incl_yes={(df.included=='yes').sum():3d} prim_rl={(df.study_type=='primary_rl_building').sum():3d} "
          f"rb_yes={(df.real_building=='yes').sum():2d} doi={(df.doi!='').sum():3d} "
          f"bad_type={sorted(set(df.study_type)-{'primary_rl_building','primary_other_building','review','method_background','tool_dataset','other'})} "
          f"bad_incl={sorted(set(df.included)-{'yes','no','no_table','unclear'})}")
all_=pd.concat(frames,ignore_index=True)
all_.to_pickle(os.path.join(D,"..","all.pkl"))
print("TOTAL rows",len(all_), "primary_rl_building",(all_.study_type=='primary_rl_building').sum())
