import pandas as pd, sys
W=sys.argv[1]
df=pd.read_pickle(f"{W}/refs_linked.pkl"); works=pd.read_pickle(f"{W}/works.pkl")
prim=works[works.type_majority=="primary_rl_building"]
for label,sel in [("any survey labels it real-building",prim.rb_yes>=1),
                  ("more 'yes' than 'no' labels",prim.rb_yes>prim.rb_no)]:
    D=prim[sel]
    d=df[df.work.isin(D.index)]
    pres=d.groupby("work").survey_id.nunique()
    print(f"\n[{label}] distinct deployment studies r={len(D)}  citations N={int(pres.sum())}  surveys citing >=1: {d.survey_id.nunique()}  cited by >=3 surveys: {int((pres>=3).sum())}  by 1 only: {int((pres==1).sum())}")
    print("  conflicting labels (some yes, some no):",int(((D.rb_yes>0)&(D.rb_no>0)).sum()))
D=prim[prim.rb_yes>prim.rb_no].copy(); D["n"]=df[df.work.isin(D.index)].groupby("work").survey_id.nunique()
print(D.sort_values("n",ascending=False).head(10)[["n","first_author","year","title","surveys"]].to_string(max_colwidth=60))
print("\nSAC / EMPA NEST check:")
m=df[df.title.str.contains("Real building implementation of a deep reinforcement|NEST|thermally activated",case=False,regex=True)]
print(m[["survey_id","ref_no","first_author_surname","year","title","real_building","work"]].to_string(max_colwidth=80))
