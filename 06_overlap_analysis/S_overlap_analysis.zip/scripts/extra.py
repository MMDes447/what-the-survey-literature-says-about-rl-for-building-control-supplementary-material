import pandas as pd, numpy as np, sys, itertools
W=sys.argv[1]
df=pd.read_pickle(f"{W}/refs_linked.pkl"); works=pd.read_pickle(f"{W}/works.pkl")
J=pd.read_csv(f"{W}/pairwise_cca_L1.csv",index_col=0)
def cca_from(sel):
    d=df[df.work.isin(sel)]; P=pd.crosstab(d.survey_id,d.work).clip(upper=1)
    c,N,r=P.shape[0],int(P.values.sum()),P.shape[1]; return c,N,r,100*(N-r)/(r*c-r)
print("sensitivity, primary if ANY survey says primary:",cca_from(set(works.index[works.type_any_primary])))
print("sensitivity, ALL cited works of any type:",cca_from(set(works.index)))
G={"broad":["MasonGrijalva2019","WangHong2020","FuEtAl2022","ZhangEtAl2022","ShaqourHagishima2022","YuEtAl2021","HuynhEtAl2025","MazharEtAl2026"],
   "hvac":["SierlaEtAl2022","AlSayedEtAl2024","ChatterjeeKhovalyg2023","Togashi2025"],
   "residential":["AlAniDas2022","LatonEtAl2024","PinthuratEtAl2024","MichailidisEtAl2025"],
   "single":["WeinbergEtAl2023","HanEtAl2021","LeiEtAl2026","KannariEtAl2025","MohsenpourXing2026","LiEtAl2025"]}
g_of={s:k for k,v in G.items() for s in v}
within,between=[],[]
for a,b in itertools.combinations(J.index,2):
    v=J.loc[b,a] if not np.isnan(J.loc[b,a]) else J.loc[a,b]
    (within if g_of[a]==g_of[b] else between).append(v)
print(f"within-scope pairs n={len(within)} median={np.median(within):.1f} mean={np.mean(within):.1f}")
print(f"between-scope pairs n={len(between)} median={np.median(between):.1f} mean={np.mean(between):.1f}")
for k,v in G.items():
    vals=[J.loc[b,a] if not np.isnan(J.loc[b,a]) else J.loc[a,b] for a,b in itertools.combinations(v,2)]
    print(f"  {k:12s} within mean={np.mean(vals):.1f} median={np.median(vals):.1f}")
# period
yr={s:int(s[-4:]) for s in J.index}
early=[s for s in J.index if yr[s]<=2022]; late=[s for s in J.index if yr[s]>=2023]
def mean_pairs(A,B=None):
    vals=[]
    for a in A:
        for b in (B if B else A):
            if a<b if B is None else True:
                if a==b: continue
                v=J.loc[b,a] if not np.isnan(J.loc[b,a]) else J.loc[a,b]; vals.append(v)
    return np.mean(vals),np.median(vals)
print("early-early",mean_pairs(early),"late-late",mean_pairs(late),"early-late",mean_pairs(early,late))
