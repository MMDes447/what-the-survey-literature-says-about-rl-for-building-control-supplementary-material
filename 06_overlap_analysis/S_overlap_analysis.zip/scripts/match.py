import pandas as pd, re, unicodedata, sys, itertools, collections
from rapidfuzz import fuzz, process
W=sys.argv[1]
df=pd.read_pickle(f"{W}/all.pkl").reset_index(drop=True)
def norm(s):
    s=unicodedata.normalize("NFKD",str(s)).encode("ascii","ignore").decode().lower()
    s=s.replace("&"," and ")
    return re.sub(r"[^a-z0-9]","",s)
def ndoi(d):
    d=d.strip().lower()
    d=re.sub(r"^(https?://)?(dx\.)?doi\.org/","",d); d=re.sub(r"^doi:\s*","",d)
    d=re.sub(r"/(bibtex|tables/\d+|metrics|figures/\d+)$","",d)
    return d.rstrip(".")
SUF=re.compile(r"\s[-|–]\s*(sciencedirect|ieee xplore|springerlink|researchgate|mdpi|arxiv)\s*$",re.I)
df["nt"]=df.title.str.replace(SUF,"",regex=True).map(norm); df["nd"]=df.doi.map(ndoi); df["fa"]=df.first_author_surname.map(norm)
df["yr"]=pd.to_numeric(df.year.str.extract(r"(\d{4})")[0],errors="coerce")
# union-find
par=list(range(len(df)))
def f(i):
    while par[i]!=i: par[i]=par[par[i]]; i=par[i]
    return i
def u(a,b,why,log):
    ra,rb=f(a),f(b)
    if ra!=rb: par[ra]=rb; log.append(why)
log=[]
# 1 DOI
for d,g in df[df.nd.str.len()>6].groupby("nd"):
    ix=list(g.index)
    for j in ix[1:]: u(ix[0],j,"doi",log)
# 2 exact normalized title (min length to avoid generic titles)
for t,g in df[df.nt.str.len()>=25].groupby("nt"):
    ix=list(g.index)
    for j in ix[1:]: u(ix[0],j,"title_exact",log)
print("links: ",collections.Counter(log))
# 3 fuzzy candidates between current clusters (titles >=25 chars), ratio>=92, |year diff|<=1 or missing
reps={}
for i in df.index:
    if len(df.nt[i])>=25: reps.setdefault(f(i),i)
keys=list(reps.keys()); titles=[df.nt[reps[k]] for k in keys]
fuzzy=[]
for a in range(len(keys)):
    res=process.extract(titles[a],titles,scorer=fuzz.ratio,score_cutoff=90,limit=10)
    for t,sc,b in res:
        if b<=a: continue
        ia,ib=reps[keys[a]],reps[keys[b]]
        ya,yb=df.yr[ia],df.yr[ib]
        yok = pd.isna(ya) or pd.isna(yb) or abs(ya-yb)<=1
        fuzzy.append((sc,yok,df.fa[ia]==df.fa[ib],ia,ib))
fz=pd.DataFrame(fuzzy,columns=["score","year_ok","same_first_author","i","j"])
fz["title_i"]=fz.i.map(df.title); fz["title_j"]=fz.j.map(df.title)
fz["auth_i"]=fz.i.map(df.first_author_surname); fz["auth_j"]=fz.j.map(df.first_author_surname)
fz["year_i"]=fz.i.map(df.year); fz["year_j"]=fz.j.map(df.year)
fz["surv_i"]=fz.i.map(df.survey_id); fz["surv_j"]=fz.j.map(df.survey_id)
fz.to_csv(f"{W}/fuzzy_candidates.csv",index=False)
print("fuzzy candidates:",len(fz), " auto-accept (>=95, year ok, same 1st author):",((fz.score>=95)&fz.year_ok&fz.same_first_author).sum())
pd.to_pickle((df,par),f"{W}/stage1.pkl")
