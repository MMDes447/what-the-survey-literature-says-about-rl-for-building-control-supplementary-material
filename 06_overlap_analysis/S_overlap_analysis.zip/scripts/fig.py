import pandas as pd, numpy as np, matplotlib, sys
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
cmap_warm=LinearSegmentedColormap.from_list("mrq_warm",["#f7f3ef","#e7d3b0","#e78124","#c0392b"])
W=sys.argv[1]; out=sys.argv[2]
J=pd.read_csv(f"{W}/pairwise_cca_L1.csv",index_col=0)
lab={"MasonGrijalva2019":"Mason & Grijalva (2019)","WangHong2020":"Wang & Hong (2020)","HanEtAl2021":"Han et al. (2021)","YuEtAl2021":"Yu et al. (2021)","AlAniDas2022":"Al-Ani & Das (2022)","FuEtAl2022":"Fu et al. (2022)","ShaqourHagishima2022":"Shaqour & Hagishima (2022)","SierlaEtAl2022":"Sierla et al. (2022)","ZhangEtAl2022":"Zhang et al. (2022)","ChatterjeeKhovalyg2023":"Chatterjee & Khovalyg (2023)","WeinbergEtAl2023":"Weinberg et al. (2023)","AlSayedEtAl2024":"Al Sayed et al. (2024)","LatonEtAl2024":"Latoń et al. (2024)","PinthuratEtAl2024":"Pinthurat et al. (2024)","HuynhEtAl2025":"Huynh et al. (2025)","KannariEtAl2025":"Kannari et al. (2025)","LiEtAl2025":"Li et al. (2025)","MichailidisEtAl2025":"Michailidis et al. (2025)","Togashi2025":"Togashi (2025)","LeiEtAl2026":"Lei et al. (2026)","MazharEtAl2026":"Mazhar et al. (2026)","MohsenpourXing2026":"Mohsenpour & Xing (2026)"}
M=J.values; n=len(J); names=[lab[s] for s in J.index]; yrs=[int(s[-4:]) for s in J.index]
fig,ax=plt.subplots(figsize=(9.5,8.0),dpi=200)
im=ax.imshow(M,cmap=cmap_warm,vmin=0,vmax=25)
for i in range(n):
    for j in range(i):
        v=M[i,j]; ax.text(j,i,f"{v:.0f}",ha="center",va="center",fontsize=6.5,color="white" if v>12 else "#2b2b2b")
ax.set_xticks(range(n)); ax.set_yticks(range(n))
ax.set_xticklabels(names,rotation=90,fontsize=8); ax.set_yticklabels(names,fontsize=8)
for k in range(1,n):
    if yrs[k]!=yrs[k-1]:
        ax.plot([-0.5,k-0.5],[k-0.5,k-0.5],color="#777",lw=0.6,ls="--")
        ax.plot([k-0.5,k-0.5],[k-0.5,n-0.5],color="#777",lw=0.6,ls="--")
for s in ax.spines.values(): s.set_visible(False)
ax.tick_params(length=0)
cb=fig.colorbar(im,ax=ax,fraction=0.035,pad=0.02,extend="max"); cb.ax.tick_params(labelsize=7); cb.set_label("Pairwise CCA (%)",fontsize=8)
plt.tight_layout(); plt.savefig(out,bbox_inches="tight"); plt.savefig(out.replace(".pdf",".png"),bbox_inches="tight",dpi=200)
