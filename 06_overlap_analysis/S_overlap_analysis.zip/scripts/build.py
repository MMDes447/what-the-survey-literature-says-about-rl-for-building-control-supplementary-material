import pandas as pd, numpy as np, sys, collections
W=sys.argv[1]
df,par=pd.read_pickle(f"{W}/stage1.pkl")
def f(i):
    while par[i]!=i: par[i]=par[par[i]]; i=par[i]
    return i
fz=pd.read_csv(f"{W}/fuzzy_candidates.csv")
ACCEPT={4,11,10,1,6,7}   # manual decisions, see fuzzy_decisions.csv
for k,r in fz.iterrows():
    if k in ACCEPT:
        a,b=f(int(r.i)),f(int(r.j))
        if a!=b: par[a]=b
fz["decision"]=["merge" if k in ACCEPT else "keep separate" for k in fz.index]
fz.to_csv(f"{W}/fuzzy_decisions.csv",index=False)
df["work"]=[f(i) for i in df.index]
# work-level attributes
def maj(s):
    c=collections.Counter(s); return c.most_common(1)[0][0]
g=df.groupby("work")
works=pd.DataFrame({
 "title":g.title.first(),"first_author":g.first_author_surname.first(),"year":g.year.first(),
 "n_surveys":g.survey_id.nunique(),
 "surveys":g.survey_id.apply(lambda s:"; ".join(sorted(set(s)))),
 "type_majority":g.study_type.agg(maj),
 "type_any_primary":g.study_type.apply(lambda s:(s=="primary_rl_building").any()),
 "type_mixed":g.study_type.apply(lambda s:s.nunique()>1),
 "rb_yes":g.real_building.apply(lambda s:(s=="yes").sum()),
 "rb_no":g.real_building.apply(lambda s:(s=="no").sum()),
 "included_by":g.apply(lambda x:"; ".join(sorted(set(x.survey_id[x.included=="yes"])))),
})
works["n_included"]=g.apply(lambda x:x.survey_id[x.included=="yes"].nunique())
works.to_pickle(f"{W}/works.pkl"); df.to_pickle(f"{W}/refs_linked.pkl")
print("rows",len(df)," distinct works",len(works))
print("primary (majority)",(works.type_majority=="primary_rl_building").sum()," primary (any)",works.type_any_primary.sum()," mixed-type works",works.type_mixed.sum())
