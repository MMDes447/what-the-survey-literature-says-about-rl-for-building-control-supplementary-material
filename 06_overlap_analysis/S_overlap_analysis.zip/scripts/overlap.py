import pandas as pd, numpy as np, sys, itertools
W=sys.argv[1]
df=pd.read_pickle(f"{W}/refs_linked.pkl"); works=pd.read_pickle(f"{W}/works.pkl")
ORDER=["MasonGrijalva2019","WangHong2020","HanEtAl2021","YuEtAl2021","AlAniDas2022","FuEtAl2022","ShaqourHagishima2022","SierlaEtAl2022","ZhangEtAl2022","ChatterjeeKhovalyg2023","WeinbergEtAl2023","AlSayedEtAl2024","LatonEtAl2024","PinthuratEtAl2024","HuynhEtAl2025","KannariEtAl2025","LiEtAl2025","MichailidisEtAl2025","Togashi2025","LeiEtAl2026","MazharEtAl2026","MohsenpourXing2026"]
prim=set(works.index[works.type_majority=="primary_rl_building"])
def cca(P):  # P: surveys x works binary DataFrame
    P=P.loc[:,P.sum()>0]; c=P.shape[0]; N=int(P.values.sum()); r=P.shape[1]
    return c,N,r,(N-r)/(r*c-r) if r and c>1 else np.nan
# level 1: cited primary studies
d1=df[df.work.isin(prim)]
P1=pd.crosstab(d1.survey_id,d1.work).clip(upper=1).reindex(ORDER).fillna(0).astype(int)
# level 2: primary studies listed as reviewed (included=yes)
d2=d1[d1.included=="yes"]
per=d2.groupby("survey_id").work.nunique().reindex(ORDER).fillna(0).astype(int)
print("primary studies listed as reviewed, per survey:\n",per.to_string())
S2=[s for s in ORDER if per[s]>=5]
P2=pd.crosstab(d2.survey_id,d2.work).clip(upper=1).reindex(S2).fillna(0).astype(int)
for name,P in [("L1 cited, all 22",P1),(f"L2 reviewed, {len(S2)} surveys",P2)]:
    c,N,r,v=cca(P); ns=P.sum()
    print(f"\n{name}: c={c} N={N} r={r} CCA={100*v:.2f}%  single-survey studies={int((ns==1).sum())} ({100*(ns==1).mean():.1f}%)  in>=5 surveys={int((ns>=5).sum())}  max={int(ns.max())}")
# pairwise (Jaccard = 2-review CCA) on level 1
J=pd.DataFrame(np.nan,index=ORDER,columns=ORDER); S=J.copy()
for a,b in itertools.combinations(ORDER,2):
    A=P1.loc[a].astype(bool); B=P1.loc[b].astype(bool)
    inter=int((A&B).sum()); uni=int((A|B).sum())
    J.loc[b,a]=100*inter/uni if uni else 0; S.loc[b,a]=inter
J.to_csv(f"{W}/pairwise_cca_L1.csv"); S.to_csv(f"{W}/pairwise_shared_L1.csv")
P1.to_csv(f"{W}/presence_L1.csv"); P2.to_csv(f"{W}/presence_L2.csv")
v=J.stack(); print("\npairwise CCA L1: median %.1f%%, mean %.1f%%, max %.1f%%"%(v.median(),v.mean(),v.max()))
print("top pairs:"); print(v.sort_values(ascending=False).head(8).round(1).to_string())
print("pairs with 0 shared:",int((S.stack()==0).sum())," of ",len(v))
# per survey: share of its primary citations that also appear elsewhere
ns=P1.sum(); 
uniq=(P1.loc[:,ns==1].sum(axis=1)/P1.sum(axis=1)*100).round(1)
print("\n% of each survey's cited primary studies cited by no other survey:\n",uniq.to_string())
# most cited studies
top=works.loc[list(prim)].copy(); top["n"]=P1.sum().reindex(top.index).fillna(0).astype(int)
print("\nmost-cited primary studies:"); print(top.sort_values("n",ascending=False).head(12)[["n","first_author","year","title"]].to_string(max_colwidth=70))
