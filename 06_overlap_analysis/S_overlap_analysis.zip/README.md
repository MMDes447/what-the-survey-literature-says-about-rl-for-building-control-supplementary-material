# Overlap of primary studies across the 22 reviews (Section 5.2)

This folder contains the data and code behind the overlap analysis in Section 5.2 of the manuscript.

## Contents

### `reference_lists/` — one CSV per review (22 files, 2,926 entries)
The complete reference list of each review, one row per printed reference.

| Column | Meaning |
|---|---|
| `survey_id` | Review identifier (e.g. `WangHong2020`) |
| `ref_no` | Reference number as printed in the review |
| `first_author_surname`, `all_authors`, `year`, `title`, `venue`, `doi` | Bibliographic fields as printed |
| `included` | `yes` if the review lists the study among its reviewed studies (study table or equivalent) |
| `included_evidence` | Where in the review the inclusion is shown |
| `study_type` | `primary_rl_building` (a primary study applying RL to building control) or another type (review, method, tool/dataset, other) |
| `real_building` | `yes` if the citing review describes the study as a real-building deployment |
| `uncertain` | `yes` where the classification was not clear from the review |
| `notes` | Transcription notes |

Each transcribed title was checked against the full text of its source review.

### `results/`
| File | Content |
|---|---|
| `S_matched_primary_studies.csv` | The 568 distinct primary studies, with the reviews citing each one, the reviews listing it as reviewed, and its real-building label |
| `S_near_match_decisions.csv` | The 17 near-matches resolved manually (6 merged, 11 kept separate) |
| `presence_L1.csv` | Review × primary-study citation matrix (all 22 reviews) |
| `presence_L2.csv` | Review × primary-study matrix for studies listed as reviewed (17 reviews) |
| `pairwise_cca_L1.csv` | Pairwise CCA (%) between reviews (Figure 4) |
| `pairwise_shared_L1.csv` | Number of shared primary studies for each pair of reviews |

### `scripts/`
Run from this folder, in order:

```
python scripts/load.py reference_lists      # combine the 22 lists -> all.pkl
python scripts/match.py .                   # match by DOI, then normalized title; list near-match candidates
python scripts/build.py .                   # apply the manual near-match decisions; build distinct works
python scripts/overlap.py .                 # CCA at both levels, pairwise CCA, matrices
python scripts/extra.py .                   # pairwise CCA within and between declared-scope groups
python scripts/deploy.py .                  # real-building deployments: citations vs distinct studies
python scripts/fig.py . overlap_pairwise_cca.pdf   # Figure 4
```

Requirements: Python 3, pandas, numpy, matplotlib, rapidfuzz.
`verify_titles.py` checks each transcribed title against the review PDFs; it needs the 22 PDFs, which are not redistributed here for copyright reasons.

## Key results reproduced by the scripts
- 2,926 reference entries resolve to 1,984 distinct works, of which 568 are primary studies applying RL to building control.
- CCA, cited primary studies (22 reviews): 5.4% (N = 1,210, r = 568).
- CCA, primary studies listed as reviewed (17 reviews): 5.3% (N = 885, r = 480).
- 52 primary studies are cited by five or more reviews; more than half appear in a single review.
- Median pairwise CCA: 17.3% among the HVAC-focused reviews, 3.2% among the single-dimension reviews; largest pairwise value 44.8%.
- Real-building deployments: 138 citations resolve to 45 distinct studies.

CCA = (N − r) / (rc − r), following Pieper et al. (2014).
